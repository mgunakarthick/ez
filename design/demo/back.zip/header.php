<header>
		<section class="container">
			<div class="row topHead">
				<div class="col-12 col-sm-12 col-md-6 none">
					<a href="#">AboutUs</a>
					<a href="#">Contact Us</a>
					<a href="#">FAQ</a>
				</div>
				<div class="col-12 col-sm-12 col-md-6 algin-right">
					<a href="login.php">Login </a>
					<a href="user-registration.php">Registration </a>
					<a href="retailer-login.php">Retailer</a>
					<a href="distributor-login.php">Distributor</a>
				</div>
			</div>
			<div class="row" >
				<div class="col-6">
					<a href="index.php" class="logo"><img src="images/Eazy-pay-logo.png" ></a>
				</div>
				<div class="col-6 algin-right">
					<div class="wallet"><img src="images/wallet.png" /> <strong>Rs. 2000</strong></div>
				</div>
			</div>
		</section>
	</header>