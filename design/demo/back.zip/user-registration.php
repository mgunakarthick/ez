<!DOCTYPE html>
<html>
<head>
<title>Eazy-pay - Online Recharge Portal</title>
<?php include "style.php" ?>
<link rel="stylesheet" type="text/css" href="css/user.css">
</head>
<body>
<section class="backimages">
    <?php include "header.php" ?>
</section>
  	<div class="container user-regiser">
    	<div class="row">
        	<div class="col-md-6 mb30">
            	<h1>Registration / Sign Up</h1>
                <div class="row">
                	<div class="col-12">
                    	<div>
                        	<label>Email ID</label><br/>
                            <input type="email" placeholder="Enter Email Id" />
                        </div>
                        <div>
                        	<label>Mobile Number</label><br/>
                            <input type="text" placeholder="Enter Mobile Number" />
                        </div>
                    </div>
                    <div class="col-12">
                    	<div>
                        	<label>Password</label><br/>
                            <input type="password" placeholder="Enter Password" />
                        </div>
                        <div>
                        	<label>Confirm Password</label><br/>
                            <input type="password" placeholder="Confirm Password" />
                        </div>
                    </div>
                    <div class="col-sm-12"><form action="profile.php"><input type="submit" value="Register" /></form></div>
                    <div class="clearfix"></div>
                    <div class="col-sm-12 reg-social">
                    	<p><span>Or</span>Registration via your social account</p>
                        <a href="#"><i class="fa fa-facebook-square"></i></a>
                         <a href="#"><i class="fa fa-twitter-square"></i></a>
                    </div>
                     <div class="col-12 registerNow">
                        <p>Already have an account <a href="login.php">Login Now</a>
                    </div>
                </div>
            </div>
            <div class="col-md-5 col-md-offset-1 ques">
            	<h1>Become a Member</h1>
                <div class="row">
                	<div class="col-sm-12">
                    	<div>
                        	<label>Lorem Ipsum is simply dummy text of the printing and typesetting industry.?</label><br/>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                            <label>Lorem Ipsum is simply dummy text of the printing?</label><br/>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        </div>
                       
                    </div>                    
                    
                </div>
            </div>
        </div>
    </div>
	
    <?php include "footer.php"; ?>
  
</body>
</html>

