<section class="rechargeBar">
    <div class="container">
        <ul>
            <li><a href="mobile-recharge.php"><img src="images/smartphone.png" /> <span>Mobile</span></a></li>
            <li><a href="data-recharge.php"><img src="images/pendrive.png" /> <span>Data Card</a></li></span>
            <li><a href="dth-recharge.php"><img src="images/satellite-tv.png" /> <span>DTH</span></a></li>
            <li><a href="bill-options.php"><img src="images/receipt.png" /> <span>Bill Payment</span></a></li>
            <li><a href="money-transfer.php"><img src="images/money-transfer.png" /> <span>Money Transfer</span></a></li>
        </ul>
    </div>
</section>